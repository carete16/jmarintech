#!/bin/bash

# ==========================================
#   MASBARATO EXPRESS | LANZADOR PRO
# ==========================================

# 1. Determinar ruta absoluta
BASEDIR=$(dirname "$0")
cd "$BASEDIR" || exit

echo "------------------------------------------"
echo "📂 TRABAJANDO EN: $(pwd)"
echo "------------------------------------------"

# 2. Limpieza de procesos y puertos
echo "🧹 Limpiando entorno..."
lsof -ti :10000 | xargs kill -9 2>/dev/null
killall -9 "Google Chrome for Testing" 2>/dev/null

# 3. Auto-reparación rápida si falta algo
if [ ! -d "node_modules" ]; then
    echo "⚙️  Instalando motores necesarios (esto solo ocurre una vez)..."
    npm install
fi

# 4. Lanzar servidor y abrir navegador
echo "🚀 Iniciando Masbarato Express..."
echo "🌍 URL: http://localhost:10000"
echo "⚙️  ADMIN: http://localhost:10000/admin"
echo "------------------------------------------"

# Abrir el navegador automáticamente después de 2 segundos
(sleep 2 && open "http://localhost:10000/admin") &

export NODE_ENV=production
node index.js
